Topics = new Meteor.Collection('Topics');
Threads = new Meteor.Collection('Threads');
Posts = new Meteor.Collection('Posts');