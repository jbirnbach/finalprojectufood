# Forum engine in 15 minutes using Meteor and AngularJS

This is the example project for the tutorial.

[![Contact me on Codementor](https://cdn.codementor.io/badges/contact_me_github.svg)](https://www.codementor.io/tibi?utm_source=github&utm_medium=button&utm_term=tibi&utm_campaign=github)
